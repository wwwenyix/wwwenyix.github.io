module.exports = {
  trailingComma: 'none',
  singleQuote: true
};
